// placeholder for services/notify.js
