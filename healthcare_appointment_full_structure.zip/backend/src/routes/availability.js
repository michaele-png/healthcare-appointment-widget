// placeholder for routes/availability.js
