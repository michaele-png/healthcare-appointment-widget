// placeholder for config/database.js
