// placeholder for components/StepIndicator.tsx
