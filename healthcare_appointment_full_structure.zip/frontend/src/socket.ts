// placeholder for socket.ts
