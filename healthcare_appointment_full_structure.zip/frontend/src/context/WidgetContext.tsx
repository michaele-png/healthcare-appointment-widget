// placeholder for context/WidgetContext.tsx
