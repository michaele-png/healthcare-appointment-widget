// placeholder for steps/PatientInfoStep.tsx
