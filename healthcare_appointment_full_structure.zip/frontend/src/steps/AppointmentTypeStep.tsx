// placeholder for steps/AppointmentTypeStep.tsx
