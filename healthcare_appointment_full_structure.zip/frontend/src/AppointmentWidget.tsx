// placeholder for AppointmentWidget.tsx
